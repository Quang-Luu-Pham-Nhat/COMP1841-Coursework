<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../posts.css">
        <title><?=$title?></title>
    </head>
    <body>
        <header id="admin">
            <h1>Internet Post Database Admin Area<br />
            Manage posts, modules and users</h1>
        </header>
        <nav>
            <ul>
                <li><a href="posts.php">Posts List</a></li>
                <li><a href="addpost.php">Add a new post</a></li>
                <li><a href="login/Logout.php">Public Site/Logout</a></li>
                <li><a href="modules.php">Modules List</a></li>
                <li><a href="users.php">Users List</a></li>
                <li><a href="view_contact_send.php">View Send Message</a></li>
            </ul>
        </nav>
        <main>
            <?=$output?>
        </main>
        <footer>&copy; IJDB 2023</footer>
    </body>
</html>