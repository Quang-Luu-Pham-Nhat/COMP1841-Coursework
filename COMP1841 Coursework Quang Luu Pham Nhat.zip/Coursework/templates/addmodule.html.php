<h2>Add a New Module</h2>
<form action="" method="post">
    <label for="moduleName">Module Name:</label>
    <input type="text" name="moduleName" id="moduleName" required>
    <button type="submit">Add Module</button>
</form>
