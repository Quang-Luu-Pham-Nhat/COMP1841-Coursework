<form action="" method="post">
    <input type="hidden" name="id" value="<?= $user['id'] ?>">

    <label for="name">User Name:</label>
    <input type="text" name="name" id="name" value="<?= $user['name'] ?>" required>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" value="<?= $user['email'] ?>" required>

    <button type="submit">Update User</button>
</form>
