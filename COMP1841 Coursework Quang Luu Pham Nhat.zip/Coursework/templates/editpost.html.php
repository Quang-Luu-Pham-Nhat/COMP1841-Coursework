<form action="" method="post">
        <input type="hidden" name="postid" value="<?=$post['id']?>">
        <label for='posttext'>Edit your post here:</label>
        <textarea name="posttext" rows="3" cols="40">
        <?=$post['posttext']?>
        </textarea>

        <label for="users">Edit User:</label>
    <select name="users">
    <option value="<?= htmlspecialchars($post['userid'], ENT_QUOTES, 'UTF-8'); ?>">
            <?= htmlspecialchars($post['username'], ENT_QUOTES, 'UTF-8'); ?>
        </option>
        <?php foreach ($users as $user):?>
        <option value="<?php echo htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
            <?php echo htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8'); ?>
        </option>
        <?php endforeach;?>
    </select>

        <label for="modules">Edit Module:</label>
    <select name="modules">
    <option value="<?= htmlspecialchars($post['moduleid'], ENT_QUOTES, 'UTF-8'); ?>">
            <?= htmlspecialchars($post['moduleName'], ENT_QUOTES, 'UTF-8'); ?>
        </option>
        <?php foreach ($modules as $module):?>
        <option value="<?php echo htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8'); ?>">
            <?php echo htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8'); ?>
        </option>
        <?php endforeach;?>
    </select>


        <input type="submit" name="submit" value="Save">
</form>