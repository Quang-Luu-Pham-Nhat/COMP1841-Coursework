<form action="" method="post">
    <label for="name">User Name:</label>
    <input type="text" name="name" id="name" required>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required>

    <button type="submit">Add User</button>
</form>
