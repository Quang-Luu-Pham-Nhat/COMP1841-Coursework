<p><?=$totalPosts?> posts have been submitted to the Internet Post Database.</p>

<?php if(isset($error)): ?>
        <p> <?=$error ?> </p>
    <?php else:?>
        <table border='1px'> 
        <?php foreach($posts as $post): ?>
        <tr>
        <td width="300px"> <?=htmlspecialchars($post['posttext'], ENT_QUOTES, 'UTF-8')?>

        <br /><?=htmlspecialchars($post['moduleName'], ENT_QUOTES, 'UTF-8')?>

        (by <a href="mailto:<?=htmlspecialchars($post['email'], ENT_QUOTES, 'UTF-8');?>">
        <?=htmlspecialchars($post['name'], ENT_QUOTES, 'UTF-8'); ?></a>)

        <td width="150px"> <?php $display_date = date ("D d M Y", strtotime($post['postdate']))?>
        <?=htmlspecialchars($display_date, ENT_QUOTES, 'UTF-8')?>
        <td width="150px">
        <img height="100px" src="images/<?=htmlspecialchars($post['image'], ENT_QUOTES, 'UTF-8'); ?>" /></td>
        </tr>
        <?php endforeach;?>
            </table>
            <?php endif;?>