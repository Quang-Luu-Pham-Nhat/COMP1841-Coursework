<h2>Edit Module</h2>
<form action="" method="post">
    <input type="hidden" name="id" value="<?= $module['id'] ?>">
    <label for="moduleName">Module Name:</label>
    <input type="text" name="moduleName" id="moduleName" value="<?= htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8') ?>" required>
    <button type="submit">Update Module</button>
</form>
