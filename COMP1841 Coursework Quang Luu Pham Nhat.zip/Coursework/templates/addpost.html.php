<form action="" method="post" enctype="multipart/form-data">
    <label for="posttext">Type your post here:</label>
    <textarea name="posttext" rows="3" cols="40"></textarea>

    <select name="users">
        <option value="">select an user</option>
        <?php foreach ($users as $user):?>
        <option value="<?php echo htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
            <?php echo htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8'); ?>
        </option>
        <?php endforeach;?>
    </select>

    <select name="modules">
        <option value="">select a module</option>
        <?php foreach ($modules as $module):?>
        <option value="<?php echo htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8'); ?>">
            <?php echo htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8'); ?>
        </option>
        <?php endforeach;?>
    </select>
    <label for="image">Upload an image:</label>
    <input type="file" name="fileToUpload">
    <input type="submit" name="submit" value="Add">
</form>