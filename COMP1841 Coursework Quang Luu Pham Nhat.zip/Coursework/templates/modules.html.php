<h2>Modules List (<?= $totalModules ?>)</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Module Name</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($modules as $module): ?>
        <tr>
            <td><?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8') ?></td>
            <td><?= htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8') ?></td>
            <td>
                <a href="editmodule.php?id=<?= $module['id'] ?>">Edit</a> |
                <a href="deletemodule.php?id=<?= $module['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
<a href="addmodule.php">Add a new module</a>