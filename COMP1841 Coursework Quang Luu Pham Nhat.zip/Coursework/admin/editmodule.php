<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

if (isset($_GET['id'])) {
    $module = query($pdo, 'SELECT * FROM module WHERE id = :id', ['id' => $_GET['id']])->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    query($pdo, 'UPDATE module SET moduleName = :name WHERE id = :id', [
        'name' => $_POST['moduleName'],
        'id' => $_POST['id']
    ]);
    header('Location: modules.php');
    exit();
}

$title = 'Edit Module';
ob_start();
include '../templates/editmodule.html.php';
$output = ob_get_clean();
include '../templates/admin_layout.html.php';
