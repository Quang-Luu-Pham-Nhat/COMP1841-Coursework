<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    query($pdo, 'INSERT INTO user (name, email) VALUES (:name, :email)', [
        'name' => $_POST['name'],
        'email' => $_POST['email']
    ]);
    header('Location: users.php');
    exit();
}

$title = 'Add User';
ob_start();
include '../templates/adduser.html.php';
$output = ob_get_clean();

include '../templates/admin_layout.html.php';
?>
