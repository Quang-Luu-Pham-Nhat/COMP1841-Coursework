<?php
if(isset($_POST ['posttext'] ) ){
    try{
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunctions.php';
        insertPost($pdo, $_POST['posttext'], $_FILES['fileToUpload'] ['name'] , $_POST['users'], $_POST['modules']);
        include '../includes/uploadFile.php';

        header('location: posts.php');
    }catch (PDOException $e) {
        $title = 'An error has occurred';
        $output = 'Database error: ' . $e->getMessage();
    }
}else{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    $title = 'Add a new post';
    $users = allUsers($pdo);
    $modules = allModules($pdo);
    ob_start();
    include '../templates/addpost.html.php' ;
    $output = ob_get_clean ();
}
include '../templates/admin_layout.html.php' ;
