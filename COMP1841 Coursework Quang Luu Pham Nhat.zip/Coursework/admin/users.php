<?php
try {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';

    $users = allUsers($pdo); // Hàm lấy toàn bộ users
    $title = 'Users List';
    $totalUsers = totalUsers($pdo); // Hàm đếm số user

    ob_start();
    include '../templates/users.html.php';
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage();
}

include '../templates/admin_layout.html.php';
