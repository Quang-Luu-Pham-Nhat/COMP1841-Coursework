<?php
try {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';

    $modules = allModules($pdo); // Hàm lấy toàn bộ modules
    $title = 'Modules List';
    $totalModules = totalModules($pdo); // Hàm đếm số module

    ob_start();
    include '../templates/modules.html.php';
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage();
}

include '../templates/admin_layout.html.php';
