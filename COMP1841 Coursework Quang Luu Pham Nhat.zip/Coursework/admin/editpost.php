<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try {
    if (isset($_POST['posttext'])) {
        updatePost($pdo, $_POST['postid'], $_POST['posttext'], $_POST['users'], $_POST['modules']);
        header('location: ../admin/posts.php');
    }else{
        $post = getPost($pdo, $_GET['id']);
        $users = allUsers($pdo);
        $modules = allModules($pdo);
        $title = 'Edit post';

        ob_start();
        include '../templates/editpost.html.php';
        $output = ob_get_clean();
    }
    } catch (PDOException $e) {
        $title = 'An error has occured';
        $output = 'Error editing post: '. $e->getMessage();
    }
include '../templates/admin_layout.html.php';