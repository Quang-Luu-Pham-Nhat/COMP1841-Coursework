<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

if (isset($_GET['id'])) {
    query($pdo, 'DELETE FROM module WHERE id = :id', ['id' => $_GET['id']]);
}

header('Location: modules.php');
exit();
