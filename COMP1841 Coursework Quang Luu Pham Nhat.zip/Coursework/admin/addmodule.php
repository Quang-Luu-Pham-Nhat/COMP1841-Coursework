<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['moduleName'];
    query($pdo, 'INSERT INTO module (moduleName) VALUES (:name)', ['name' => $name]);
    header('Location: modules.php');
    exit();
}

$title = 'Add Module';
ob_start();
include '../templates/addmodule.html.php';
$output = ob_get_clean();
include '../templates/admin_layout.html.php';
