<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        query($pdo, 'DELETE FROM user WHERE id = :id', ['id' => $id]);
        header('Location: users.php'); // Chuyển hướng về danh sách user sau khi xóa
        exit;
    } catch (PDOException $e) {
        echo "Error deleting user: " . $e->getMessage();
    }
} else {
    echo "Invalid request.";
}
