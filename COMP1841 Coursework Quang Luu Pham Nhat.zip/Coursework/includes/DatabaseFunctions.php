<?php
function totalPosts($pdo){
    $query = $pdo->prepare('SELECT COUNT(*) FROM post');
    $query->execute();
    $row = $query->fetch();
    return $row [0];
}

function query($pdo, $sql, $parameters = []) {
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}

// function getPost($pdo, $id) {
//     $parameters = [':id' => $id];
//     $query = query($pdo,"SELECT * FROM post WHERE id = :id", $parameters);
//     return $query->fetch();
// }

function getPost($pdo, $id) {
    $sql = "SELECT post.*, user.name as username, module.moduleName FROM post
            LEFT JOIN user ON post.userid = user.id
            LEFT JOIN module ON post.moduleid = module.id
            WHERE post.id = :id";  
    $parameters = [':id' => $id];
    $query = query($pdo, $sql, $parameters);
    return $query->fetch();
}


function updatePost($pdo, $postid, $posttext, $userid, $moduleid) {
    $sql = "UPDATE post SET posttext = :posttext, userid = :userid, moduleid = :moduleid  WHERE id = :id";
    $parameters = [':posttext' => $posttext, ':id' => $postid, ':userid' => $userid, ':moduleid' => $moduleid];
    query($pdo, $sql, $parameters);
}

function deletePost($pdo, $id) {
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM post WHERE id = :id', $parameters);
}

function insertPost($pdo, $posttext, $fileToUpload, $userid, $moduleid) {
	$query = 'INSERT INTO post (posttext, postdate, image, userid, moduleid)
	VALUES (:posttext, CURDATE(), :fileToUpload, :userid, :moduleid)';
	$parameters = [':posttext' => $posttext, ':fileToUpload' => $fileToUpload, ':userid' => $userid, ':moduleid' => $moduleid];
	query($pdo, $query, $parameters);
}

function allPosts($pdo) {
	$posts = query($pdo, 'SELECT post.id, posttext, postdate, image, name, email, moduleName FROM post
	INNER JOIN user ON userid = user.id
	INNER JOIN module ON moduleid = module.id');
	return $posts->fetchAll();
}

function allUsers($pdo) {
	$users = query($pdo, 'SELECT * FROM user');
	return $users->fetchAll();
}


function allModules($pdo) {
	$modules = query($pdo, 'SELECT * FROM module');
	return $modules->fetchAll();
}